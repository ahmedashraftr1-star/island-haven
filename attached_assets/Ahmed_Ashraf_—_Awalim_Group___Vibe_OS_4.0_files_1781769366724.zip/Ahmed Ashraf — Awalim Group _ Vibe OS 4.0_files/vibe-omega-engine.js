/* ╔═══════════════════════════════════════════════════════════════════════════╗
   ║  VIBE OMEGA ENGINE — Phase Omega Architecture                          ║
   ║  Magnetic Physics · Haptic Ripples · Scramble Reveals · AI Nucleus     ║
   ║  Supreme Hardware Interaction Tier · 60 FPS GPU-Driven                 ║
   ╚═══════════════════════════════════════════════════════════════════════════╝ */

(function() {
  'use strict';

  const hasHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;
  const isMobile = !hasHover;
  const reduced  = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ──────────────────────────────────────────────────────────────────────────
     1. TACTILE PHYSICS (Magnetic & Spring)
  ────────────────────────────────────────────────────────────────────────── */
  function initMagneticButtons() {
    const targets = document.querySelectorAll('.srv-book-btn, .lg-btn, .btn, .vos-tab, .vsh-btn-primary, .vsh-btn-ghost, .lg-cta, .magnetic-btn');
    
    targets.forEach(el => {
      if (!isMobile && !reduced) {
        el.addEventListener('mousemove', (e) => {
          const r = el.getBoundingClientRect();
          const x = (e.clientX - (r.left + r.width / 2)) * 0.28;
          const y = (e.clientY - (r.top + r.height / 2)) * 0.28;
          gsap.to(el, { x, y, duration: 0.4, ease: 'power2.out' });
        });
        
        el.addEventListener('mouseleave', () => {
          gsap.to(el, { x: 0, y: 0, duration: 0.6, ease: 'elastic.out(1, 0.3)' });
        });
      }

      if (isMobile) {
        el.addEventListener('touchstart', () => gsap.to(el, { scale: 0.96, duration: 0.2 }), {passive: true});
        el.addEventListener('touchend', () => gsap.to(el, { scale: 1, duration: 0.4, ease: 'elastic.out(1, 0.3)' }), {passive: true});
      }
    });
  }

  /* ──────────────────────────────────────────────────────────────────────────
     2. CINEMATIC TEXT EFFECTS (Scramble & Split)
  ────────────────────────────────────────────────────────────────────────── */
  function scrambleText(el) {
    const original = el.innerText;
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789$!@#%^&*()';
    let iter = 0;
    const interval = setInterval(() => {
      el.innerText = original.split('').map((char, i) => {
        if (i < iter) return original[i];
        return chars[Math.floor(Math.random() * chars.length)];
      }).join('');
      if (iter >= original.length) clearInterval(interval);
      iter += 1;
    }, 30);
  }

  function initSplitTitles() {
    if (reduced) return;
    document.querySelectorAll('.vsh-line-static').forEach(line => {
      const text = line.innerText.trim();
      line.innerHTML = '';
      [...text].forEach((char, i) => {
        const span = document.createElement('span');
        span.className = 'reveal';
        span.style.display = 'inline-block';
        span.innerText = char === ' ' ? '\u00A0' : char;
        span.style.transitionDelay = `${i * 0.03}s`;
        line.appendChild(span);
        setTimeout(() => span.classList.add('in-view'), 800);
      });
    });
  }

  /* ──────────────────────────────────────────────────────────────────────────
     3. MATERIAL INTERACTION (Spotlight & Perspective)
  ────────────────────────────────────────────────────────────────────────── */
  function initSpotlight() {
    if (isMobile || reduced) return;
    const cards = document.querySelectorAll('.lg-service-card, .lg-port-card, .product-card, .app-card');
    cards.forEach(card => {
      card.addEventListener('mousemove', e => {
        const r = card.getBoundingClientRect();
        const x = ((e.clientX - r.left) / r.width * 100).toFixed(1) + '%';
        const y = ((e.clientY - r.top) / r.height * 100).toFixed(1) + '%';
        card.style.setProperty('--spot-x', x);
        card.style.setProperty('--spot-y', y);
        card.style.setProperty('--card-glow', '1');
      }, { passive: true });
      card.addEventListener('mouseleave', () => card.style.setProperty('--card-glow', '0'));
    });
  }

  function init3DTilt() {
    if (isMobile || reduced) return;
    document.querySelectorAll('.lg-service-card, .lg-port-card, .product-card').forEach(card => {
      card.addEventListener('mousemove', e => {
        const r = card.getBoundingClientRect();
        const x = (e.clientX - r.left) / r.width - 0.5;
        const y = (e.clientY - r.top) / r.height - 0.5;
        gsap.to(card, { rotateX: y * -8, rotateY: x * 8, duration: 0.5, ease: 'power2.out' });
      });
      card.addEventListener('mouseleave', () => {
        gsap.to(card, { rotateX: 0, rotateY: 0, duration: 0.8, ease: 'elastic.out(1, 0.3)' });
      });
    });
  }

  /* ──────────────────────────────────────────────────────────────────────────
     4. SYSTEM ENTRANCE (Cinematic Staggers)
  ────────────────────────────────────────────────────────────────────────── */
  function initReveals() {
    const parentGroups = ['.lg-port-bento', '.lg-services-grid', '.store-grid', '.milestone-timeline'];
    parentGroups.forEach(groupSelector => {
      const group = document.querySelector(groupSelector);
      if (!group) return;
      ScrollTrigger.create({
        trigger: group,
        start: 'top 85%',
        once: true,
        onEnter: () => {
          const children = group.querySelectorAll('.reveal');
          gsap.to(children, { opacity: 1, y: 0, scale: 1, filter: 'blur(0px)', duration: 0.8, stagger: 0.07, ease: 'expo.out' });
          children.forEach(c => c.classList.add('in-view'));
        }
      });
    });

    document.querySelectorAll('.reveal:not(.in-view)').forEach(el => {
      ScrollTrigger.create({
        trigger: el, start: 'top 90%', once: true,
        onEnter: () => {
          gsap.to(el, { opacity: 1, y: 0, scale: 1, filter: 'blur(0px)', duration: 0.6, ease: 'expo.out' });
          el.classList.add('in-view');
        }
      });
    });
  }

  /* ──────────────────────────────────────────────────────────────────────────
     5. DYNAMIC TIMELINE SPINE
  ────────────────────────────────────────────────────────────────────────── */
  function initTimelineSpine() {
    const timeline = document.querySelector('.lg-timeline');
    if (!timeline) return;
    const tlStyle = document.createElement('style');
    document.head.appendChild(tlStyle);
    window.addEventListener('scroll', () => {
      const r = timeline.getBoundingClientRect();
      const pct = Math.max(0, Math.min(100, ((window.innerHeight * 0.7 - r.top) / r.height) * 100)).toFixed(1);
      tlStyle.textContent = `.lg-timeline::before { height: ${pct}% !important; }`;
    }, { passive: true });
  }

  /* ──────────────────────────────────────────────────────────────────────────
     6. SCROLL VELOCITY SKEW
  ────────────────────────────────────────────────────────────────────────── */
  function initVelocitySkew() {
    if (reduced || !window.gsap) return;
    let proxy = { skew: 0 },
        skewSetter = gsap.quickSetter(".section-title, .product-card", "skewY", "deg"),
        clamp = gsap.utils.clamp(-5, 5);

    ScrollTrigger.create({
      onUpdate: (self) => {
        let skew = clamp(self.getVelocity() / -500);
        if (Math.abs(skew) > Math.abs(proxy.skew)) {
          proxy.skew = skew;
          gsap.to(proxy, {skew: 0, duration: 0.8, ease: "power3", overwrite: true, onUpdate: () => skewSetter(proxy.skew)});
        }
      }
    });
    gsap.set(".section-title, .product-card", {transformOrigin: "right center", force3D: true});
  }

  /* ──────────────────────────────────────────────────────────────────────────
     7. INITIALIZATION
  ────────────────────────────────────────────────────────────────────────── */
  function triggerShockwave() {
    const rippleMap = document.getElementById('ripple-map');
    if (!rippleMap) return;
    gsap.timeline()
      .to(rippleMap, { attr: { scale: 60 }, duration: 0.25 })
      .to(rippleMap, { attr: { scale: 0 }, duration: 0.8, ease: 'expo.out' });
  }

  function initOmega() {
    initMagneticButtons();
    initSplitTitles();
    initSpotlight();
    init3DTilt();
    initReveals();
    initTimelineSpine();
    initVelocitySkew();
    
    document.querySelectorAll('.btn, .lg-cta, .buy-btn').forEach(btn => {
      btn.addEventListener('click', triggerShockwave);
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initOmega);
  } else {
    initOmega();
  }

})();
