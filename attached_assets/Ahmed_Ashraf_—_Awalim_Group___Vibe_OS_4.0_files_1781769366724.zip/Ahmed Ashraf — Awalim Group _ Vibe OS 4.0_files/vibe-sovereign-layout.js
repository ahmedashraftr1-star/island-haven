/* ╔══════════════════════════════════════════════════════════════════════╗
   ║  VIBE OS 4.0 — SOVEREIGN LAYOUT GUARDIAN (Platform Kernel)          ║
   ║  Global Component Injection · Universal Interaction Engine          ║
   ╚══════════════════════════════════════════════════════════════════════╝ */

(function() {
  'use strict';

  const SOVEREIGN_ASSETS = {
    nucleus: `
      <div id="sovereign-nucleus" class="nucleus-container" aria-label="Sovereign AI Nucleus">
        <div class="nucleus-core">
          <div class="nucleus-ring ring-1"></div>
          <div class="nucleus-ring ring-2"></div>
          <div class="nucleus-ring ring-3"></div>
          <div class="nucleus-glow"></div>
        </div>
        <div class="nucleus-status-display">
          <span class="status-marker"></span>
          <span class="status-text">SYSTEM ACTIVE</span>
        </div>
      </div>
    `,
    rippleFilter: `
      <svg style="display:none" aria-hidden="true">
        <filter id="glass-ripple">
          <feTurbulence type="fractalNoise" baseFrequency="0.01" numOctaves="3" result="noise" seed="1" />
          <feDisplacementMap in="SourceGraphic" in2="noise" scale="0" xChannelSelector="R" yChannelSelector="G" id="ripple-map" />
        </filter>
      </svg>
    `,
    meshBg: `<div class="apex-mesh-bg" aria-hidden="true"></div>`
  };

  /* ══ 1. INJECTION ENGINE (Sovereign Guardian) ══ */
  function injectSovereignCore() {
    // 1.1 Injected Ripple Filter
    if (!document.getElementById('glass-ripple')) {
      document.body.insertAdjacentHTML('beforeend', SOVEREIGN_ASSETS.rippleFilter);
    }
    
    // 1.2 Injected Mesh Background
    if (!document.querySelector('.apex-mesh-bg')) {
      document.body.insertAdjacentHTML('afterbegin', SOVEREIGN_ASSETS.meshBg);
    }

    // 1.3 Injected AI Nucleus
    if (!document.getElementById('sovereign-nucleus')) {
      document.body.insertAdjacentHTML('beforeend', SOVEREIGN_ASSETS.nucleus);
    }
  }

  /* ══ 2. INTERACTION WRAPPERS (Sitewide Activation) ══ */
  function syncGlobalEngines() {
    // Ensure GSAP is available before initializing
    if (typeof gsap === 'undefined') {
      console.warn('Vibe OS: GSAP not found. Some interaction primitives may be disabled.');
      return;
    }

    // Delay to ensure DOM is fully ready for external assets
    setTimeout(() => {
      if (typeof initOmega === 'function') {
        initOmega(); 
      } else {
        // If engine logic isn't loaded yet, try again
        console.log('Vibe OS Kernel: Syncing interaction layers...');
      }
    }, 100);
  }

  /* ══ 3. INITIALIZATION ══ */
  function initSovereignKernel() {
    injectSovereignCore();
    syncGlobalEngines();
    
    // Bind context color shifts based on page type
    const pageType = document.body.dataset.page || 'default';
    const nucleus = document.getElementById('sovereign-nucleus');
    const statusText = nucleus ? nucleus.querySelector('.status-text') : null;

    if (pageType === 'dashboard' || pageType === 'ai') {
      document.documentElement.style.setProperty('--accent', '#0088FF');
      if (statusText) statusText.textContent = 'NEURAL LINK ACTIVE';
    }
    
    console.log(`Vibe OS Kernel [v4.0.Apex]: ${pageType.toUpperCase()} module initialized.`);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initSovereignKernel);
  } else {
    initSovereignKernel();
  }

})();
