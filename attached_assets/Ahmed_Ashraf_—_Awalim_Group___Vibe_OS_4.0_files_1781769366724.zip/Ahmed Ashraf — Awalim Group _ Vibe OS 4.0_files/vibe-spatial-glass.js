/* ╔═══════════════════════════════════════════════════════════════════════════╗
   ║  VIBE SPATIAL GLASS — VisionOS Pro Max · Mouse-Driven Light Engine      ║
   ║  Spotlight borders · Depth shadows · Prismatic shimmer · Micro-sparkles ║
   ║  GPU-composited · 60 FPS · Zero layout thrash · prefers-reduced-motion  ║
   ╚═══════════════════════════════════════════════════════════════════════════╝ */

(function () {
  'use strict';

  const reduced  = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const hasHover = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

  /* All glass surfaces across every page */
  const GLASS_SEL = [
    '.infinity-glass', '.glass-card', '.bento-card', '.vproj-card',
    '.service-card',   '.milestone-card', '.course-card', '.course-card-full',
    '.spatial-store-card', '.product-card', '.art-card', '.vibe-step',
    '.vibe-what-card', '.instructor-card', '.persona-side', '.step-card',
    '.srv-card', '.pay-card', '.testi-marquee-card', '.lg-service-card',
    '.lg-port-card', '.lg-course-card', '.apple-glass-icon', '.founder-card'
  ].join(',');

  /* ── 0. AMBIENT CURSOR ORB ─────────────────────────────────────────────── */
  /* A large, soft lime glow that follows the cursor across the whole page */
  if (hasHover && !reduced) {
    const orb = document.createElement('div');
    orb.id = 'vsgCursorOrb';
    orb.setAttribute('aria-hidden', 'true');
    orb.style.cssText = [
      'position:fixed', 'width:700px', 'height:700px', 'border-radius:50%',
      'pointer-events:none', 'z-index:0',
      'background:radial-gradient(circle, rgba(0,189,125,0.055) 0%, rgba(0,224,198,0.025) 40%, transparent 70%)',
      'left:-350px', 'top:-350px',
      'will-change:transform'
    ].join(';');
    document.body.appendChild(orb);

    /* Spring-lerp cursor tracking & Chromatic Velocity Engine */
    let tx = -350, ty = -350, cx = -350, cy = -350;
    
    // Physics variables for Chromatic Velocity Glass
    let lastX = 0, lastY = 0, lastTime = Date.now();
    let currentChroma = 1;

    (function orbLoop() {
      // 1. Ambient Orb Physics
      cx += (tx - cx) * 0.072;
      cy += (ty - cy) * 0.072;
      orb.style.transform = `translate(${cx.toFixed(1)}px, ${cy.toFixed(1)}px)`;

      // 2. Chromatic Velocity Physics (Friction and Decay)
      // When mouse stops, slowly snap the RGB layers back to white (1px)
      currentChroma += (1 - currentChroma) * 0.08; 
      
      // Update global CSS Variables for the fractured light effect
      document.documentElement.style.setProperty('--chroma-shift', currentChroma.toFixed(2) + 'px');
      document.documentElement.style.setProperty('--chroma-blur', Math.max(1, currentChroma * 0.5).toFixed(2) + 'px');

      requestAnimationFrame(orbLoop);
    })();

    document.addEventListener('mousemove', e => {
      // Euclidean Speed Calculation for Chromatic Velocity Glass
      const now = Date.now();
      const dt = Math.max(1, now - lastTime);
      const dx = e.clientX - lastX;
      const dy = e.clientY - lastY;
      const speed = Math.sqrt(dx*dx + dy*dy) / dt; // pixels per ms
      
      // Map speed (0 to ~10px/ms) into a visual shift range of (1px to 25px)
      const targetChroma = 1 + Math.min(speed * 4, 30);
      
      // Instant spike upon movement, smoothed out by the orbLoop friction
      if (targetChroma > currentChroma) currentChroma = targetChroma;

      lastX = e.clientX;
      lastY = e.clientY;
      lastTime = now;

      tx = e.clientX - 350;
      ty = e.clientY - 350;
      /* Drive CSS vars for body::before ambient orb + card topology */
      document.documentElement.style.setProperty('--cursor-x', (e.clientX / window.innerWidth  * 100).toFixed(2) + '%');
      document.documentElement.style.setProperty('--cursor-y', (e.clientY / window.innerHeight * 100).toFixed(2) + '%');

      /* GLOBAL PROXIMITY TRACKING — Cards react when cursor is NEAR them */
      const cards = document.querySelectorAll(GLASS_SEL);
      cards.forEach(card => {
        const r = card.getBoundingClientRect();
        const cx = r.left + r.width / 2;
        const cy = r.top + r.height / 2;
        const dist = Math.sqrt(Math.pow(e.clientX - cx, 2) + Math.pow(e.clientY - cy, 2));
        
        // 400px radius of influence
        if (dist < 400) {
          const proximity = (1 - dist / 400).toFixed(3);
          card.style.setProperty('--vsg-proximity', proximity);
        } else {
          card.style.setProperty('--vsg-proximity', '0');
        }
      });
    }, { passive: true });
  }

  /* ── 1. INJECT SPOTLIGHT LAYERS INTO EACH GLASS CARD ──────────────────── */
  /*
   * Each card gets three injected children (aria-hidden):
   *   .vsg-border   — the conic-gradient spotlight border (mask-composite trick)
   *   .vsg-prism    — prismatic rainbow refraction at card surface
   *   .vsg-sparkle  — micro-sparkles via color-dodge noise (very subtle)
   *
   * All three are driven by CSS custom properties:
   *   --mouse-x, --mouse-y  (% within the card)
   *   --mouse-angle         (degrees from card center)
   *   --mouse-dist          (0=center, 1=edge — for intensity falloff)
   */
  function injectLayers(card) {
    if (card.dataset.vsgDone) return;
    card.dataset.vsgDone = '1';

    /* Guarantee stacking context */
    const cs = getComputedStyle(card);
    if (cs.position === 'static') card.style.position = 'relative';
    if (cs.isolation !== 'isolate') card.style.isolation = 'isolate';

    /* ─ Spotlight border ─ */
    const border = document.createElement('div');
    border.className = 'vsg-border';
    border.setAttribute('aria-hidden', 'true');
    card.appendChild(border);

    /* ─ Prismatic refraction ─ */
    const prism = document.createElement('div');
    prism.className = 'vsg-prism';
    prism.setAttribute('aria-hidden', 'true');
    card.appendChild(prism);

    /* ─ Micro-sparkle noise (color-dodge) ─ */
    if (!reduced) {
      const sparkle = document.createElement('div');
      sparkle.className = 'vsg-sparkle';
      sparkle.setAttribute('aria-hidden', 'true');
      card.appendChild(sparkle);
    }

    /* ─ Glass caustic (drifting internal light — JS rAF, zero @keyframes Paint) ─ */
    if (!reduced) {
      const caustic = document.createElement('div');
      caustic.className = 'vsg-caustic';
      caustic.setAttribute('aria-hidden', 'true');
      card.appendChild(caustic);

      /* Each card gets a random phase so caustics aren't synchronized */
      const phase = Math.random() * Math.PI * 2;
      const speed = 0.00035 + Math.random() * 0.0002;

      let rafId = null;
      let active = false;

      function animateCaustic(t) {
        if (!active) return;
        const tx = Math.sin(t * speed       + phase)        * 10;
        const ty = Math.cos(t * speed * 0.7 + phase + 1.2)  * 8;
        const sc = 1 + Math.sin(t * speed * 0.5 + phase)    * 0.06;
        /* Only transform — element has will-change:transform → GPU composited */
        caustic.style.transform = `translate(${tx.toFixed(2)}%, ${ty.toFixed(2)}%) scale(${sc.toFixed(4)})`;
        rafId = requestAnimationFrame(animateCaustic);
      }

      card.addEventListener('mouseenter', () => {
        if (active) return;
        active = true;
        rafId = requestAnimationFrame(animateCaustic);
      }, { passive: true });

      card.addEventListener('mouseleave', () => {
        active = false;
        if (rafId) { cancelAnimationFrame(rafId); rafId = null; }
        caustic.style.transform = '';
      }, { passive: true });
    }
  }

  /* ── 2. MOUSE EVENT HANDLER FOR EACH CARD ─────────────────────────────── */
  function bindCard(card) {
    if (!hasHover || reduced) return;

    card.addEventListener('mouseenter', () => {
      card.classList.add('vsg-active');
    }, { passive: true });

    card.addEventListener('mousemove', e => {
      const r = card.getBoundingClientRect();

      /* Position as % within card */
      const xPct = ((e.clientX - r.left) / r.width  * 100).toFixed(2);
      const yPct = ((e.clientY - r.top)  / r.height * 100).toFixed(2);

      /* Angle from card center in degrees */
      const cx  = r.left + r.width  / 2;
      const cy  = r.top  + r.height / 2;
      const ang = (Math.atan2(e.clientY - cy, e.clientX - cx) * (180 / Math.PI) + 360) % 360;

      /* Distance from center (0 = center, 1 = corner) */
      const dx   = (e.clientX - cx) / (r.width  / 2);
      const dy   = (e.clientY - cy) / (r.height / 2);
      const dist = Math.min(Math.sqrt(dx * dx + dy * dy), 1).toFixed(3);

      card.style.setProperty('--mouse-x',     xPct + '%');
      card.style.setProperty('--mouse-y',     yPct + '%');
      card.style.setProperty('--mouse-angle', ang.toFixed(1) + 'deg');
      card.style.setProperty('--mouse-dist',  dist);

      /* Depth shadow deepens as card is hovered near center */
      const lift = (1 - parseFloat(dist)) * 8;
      card.style.setProperty('--vsg-lift', lift.toFixed(1) + 'px');

    }, { passive: true });

    card.addEventListener('mouseleave', () => {
      card.classList.remove('vsg-active');
      card.style.removeProperty('--mouse-x');
      card.style.removeProperty('--mouse-y');
      card.style.removeProperty('--mouse-angle');
      card.style.removeProperty('--mouse-dist');
      card.style.removeProperty('--vsg-lift');
    }, { passive: true });
  }

  /* ── 3. INIT ALL CURRENT CARDS ──────────────────────────────────────────── */
  function initCards() {
    document.querySelectorAll(GLASS_SEL).forEach(card => {
      injectLayers(card);
      bindCard(card);
    });
  }

  /* ── 4. MUTATIONOBSERVER — catches dynamically rendered cards ──────────── */
  /* Store / community / dashboard pages render cards after DOM load */
  const mo = new MutationObserver(mutations => {
    mutations.forEach(m => {
      m.addedNodes.forEach(node => {
        if (node.nodeType !== 1) return;
        /* Check if node itself is a glass card */
        const cards = node.matches?.(GLASS_SEL)
          ? [node]
          : [...node.querySelectorAll(GLASS_SEL)];
        cards.forEach(card => { injectLayers(card); bindCard(card); });
      });
    });
  });
  mo.observe(document.body, { childList: true, subtree: true });

  /* ── 5. DEPTH VIBRANCY — text inside active glass cards ───────────────── */
  /* Adds .vsg-active body-class so CSS can style inner text vibrancy */
  /* (CSS handles this — no JS logic needed beyond the class toggle above) */

  /* ── 6. FEATURED CARD BREATHING GLOW ─────────────────────────────────── */
  /* Already in CSS via @keyframes vsgGlowBreath — JS only needs to init */

  /* ── 7. PERFORMANCE GUARD — pause when tab hidden ─────────────────────── */
  document.addEventListener('visibilitychange', () => {
    if (document.hidden && document.getElementById('vsgCursorOrb')) {
      document.getElementById('vsgCursorOrb').style.opacity = '0';
    } else if (document.getElementById('vsgCursorOrb')) {
      document.getElementById('vsgCursorOrb').style.opacity = '1';
    }
  });

  /* ── 8. APPLE GLASS ICON ENHANCED SPOTLIGHT ──────────────────────────── */
  /* Small icons (nav, dashboard) get a tighter spotlight arc */
  document.querySelectorAll('.apple-glass-icon, .icon-btn').forEach(el => {
    if (!hasHover || reduced) return;
    el.addEventListener('mousemove', e => {
      const r   = el.getBoundingClientRect();
      const x   = ((e.clientX - r.left) / r.width  * 100).toFixed(1) + '%';
      const y   = ((e.clientY - r.top)  / r.height * 100).toFixed(1) + '%';
      const ang = (Math.atan2(
        e.clientY - (r.top + r.height / 2),
        e.clientX - (r.left + r.width  / 2)
      ) * 180 / Math.PI + 360) % 360;
      el.style.setProperty('--mouse-x',     x);
      el.style.setProperty('--mouse-y',     y);
      el.style.setProperty('--mouse-angle', ang.toFixed(1) + 'deg');
    }, { passive: true });
    el.addEventListener('mouseleave', () => {
      el.style.removeProperty('--mouse-x');
      el.style.removeProperty('--mouse-y');
      el.style.removeProperty('--mouse-angle');
    }, { passive: true });
  });

  /* ── 9. FOUNDER CARD 3D PARALLAX — Dedicated high-fidelity physics ────── */
  function initFounderParallax() {
    const card = document.querySelector('.founder-card');
    if (!card || !hasHover || reduced) return;

    const portrait = card.querySelector('.founder-card-portrait img');
    
    card.addEventListener('mousemove', e => {
      const r = card.getBoundingClientRect();
      const x = e.clientX - r.left;
      const y = e.clientY - r.top;
      
      const centerX = r.width / 2;
      const centerY = r.height / 2;
      
      // Calculate rotation (max 8deg)
      const rotateX = ((centerY - y) / centerY) * 8;
      const rotateY = ((x - centerX) / centerX) * 8;
      
      card.style.transform = `perspective(1200px) rotateX(${rotateX.toFixed(2)}deg) rotateY(${rotateY.toFixed(2)}deg) translateY(-5px) scale(1.02)`;
      
      // Move portrait slightly in opposite direction for parallax depth
      if (portrait) {
        const px = (x - centerX) * 0.015;
        const py = (y - centerY) * 0.015;
        portrait.style.transform = `scale(1.1) translate(${px.toFixed(2)}px, ${py.toFixed(2)}px)`;
      }

      // HUD Spatial Parallax
      const hudLayer = card.querySelector('.hud-layer');
      if (hudLayer) {
        const hudX = (x - centerX) * 0.04;
        const hudY = (y - centerY) * 0.04;
        hudLayer.style.transform = `translate(${hudX.toFixed(2)}px, ${hudY.toFixed(2)}px) scale(1.05)`;
        
        const grid = hudLayer.querySelector('.hud-grid');
        if (grid) grid.style.transform = `perspective(1000px) rotateX(60deg) translate(${(hudX * 2).toFixed(2)}px, ${(hudY * 2).toFixed(2)}px) translateY(-50px)`;
      }
    });

    card.addEventListener('mouseleave', () => {
      card.style.transform = '';
      if (portrait) portrait.style.transform = '';
      const hudLayer = card.querySelector('.hud-layer');
      if (hudLayer) hudLayer.style.transform = '';
      const grid = card.querySelector('.hud-grid');
      if (grid) grid.style.transform = '';
    });
  }

  /* ── 10. VIBE OS KERNEL LOGGER — Real-time Terminal Feedback ──────────── */
  function initKernelLogger() {
    const consoleBody = document.getElementById('vosKernelLogs');
    const tabs = document.querySelectorAll('.vos-tab');
    if (!consoleBody || !tabs.length) return;

    function log(message) {
      const line = document.createElement('div');
      line.className = 'console-line';
      line.textContent = `> ${message}`;
      consoleBody.appendChild(line);
      consoleBody.scrollTop = consoleBody.scrollHeight;
      
      // Keep only last 8 lines
      if (consoleBody.children.length > 8) {
        consoleBody.removeChild(consoleBody.children[0]);
      }
    }

    tabs.forEach(tab => {
      tab.addEventListener('click', () => {
        const module = tab.textContent.trim();
        log(`Switching to module: [${module}]`);
        setTimeout(() => log(`Injecting shared kernels... DONE`), 200);
        setTimeout(() => log(`Optimizing spatial layout... CACHED`), 450);
      });
    });

    // Ambient background logs
    setInterval(() => {
      if (Math.random() > 0.92) {
        const sysLogs = [
          "Memory heartbeat: STABLE",
          "Entropy collection: OK",
          "Cache invalidation... 0ms",
          "Syncing with Awalim Forge...",
          "Agent state: LISTENING"
        ];
        log(sysLogs[Math.floor(Math.random() * sysLogs.length)]);
      }
    }, 4000);
  }

  /* Run after DOM is fully loaded */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      initCards();
      initFounderParallax();
      initKernelLogger();
    });
  } else {
    initCards();
    initFounderParallax();
    initKernelLogger();
  }

  /* ── 9. CINEMATIC SCROLL VELOCITY ENGINE (Apple/Google Perfection) ───────── */
  /* Apple-grade scroll physics: skew and scale elements based on scroll speed */
  if (!reduced) {
    let lastScrollY = window.scrollY;
    let velocityY = 0;
    let currentSkew = 0;
    let currentScale = 1;

    // We select heavyweight visual elements to apply the velocity physics to
    const velocityElements = () => document.querySelectorAll('.glass-card, .infinity-glass, .spatial-card, .vsh-line-word');

    function renderScrollPhysics() {
      // 1. Calculate Raw Velocity
      const currentScrollY = window.scrollY;
      const deltaY = currentScrollY - lastScrollY;
      lastScrollY = currentScrollY;

      // Smooth the velocity reading
      velocityY = velocityY * 0.8 + deltaY * 0.2;

      // 2. Map Velocity to Skew and Scale (Max bounds logic)
      let targetSkew = velocityY * -0.015; // Fast scroll down = slight upward skew
      let targetScale = 1 - Math.abs(velocityY) * 0.0003; // Fast scroll = slight shrink

      // Clamp values so it remains elegant, not chaotic
      targetSkew = Math.max(-3, Math.min(3, targetSkew));
      targetScale = Math.max(0.98, targetScale);

      // 3. Spring physics: lerp towards target
      currentSkew += (targetSkew - currentSkew) * 0.1;
      currentScale += (targetScale - currentScale) * 0.1;

      // 4. Apply to elements if delta is noticeable (optimizing GPU)
      if (Math.abs(currentSkew) > 0.01 || Math.abs(currentScale - 1) > 0.001) {
        const els = velocityElements();
        for (let i = 0; i < els.length; i++) {
          // If the element has internal transforms, we overlay this.
          // Note: using variable to not overwrite mouse-hover transforms perfectly, but for overall block, CSS variable is best.
          els[i].style.setProperty('--scroll-skew', `${currentSkew.toFixed(3)}deg`);
          els[i].style.setProperty('--scroll-scale', `${currentScale.toFixed(4)}`);
          
          // Apply via inline if no hover engine is currently dragging it (vsg-active overrides)
          if (!els[i].classList.contains('vsg-active')) {
             els[i].style.transform = `perspective(1000px) skewY(${currentSkew.toFixed(3)}deg) scale(${currentScale.toFixed(4)})`;
          }
        }
      } else {
        const els = velocityElements();
        for (let i = 0; i < els.length; i++) {
             if (!els[i].classList.contains('vsg-active')) els[i].style.transform = '';
        }
      }

      requestAnimationFrame(renderScrollPhysics);
    }

    // Start Scroll Physics Loop
    requestAnimationFrame(renderScrollPhysics);
  }

})();
